Steps to run

-Create the mysql database/tables/ from db.sql

-Run the following command from the project folder

   mvn clean package
   
-Take the war from target directory 

-Drop it in tomcat(7 or 8) webapps


-Access the app at
 
 http://localhost:8080/crudApp